-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 27, 2020 at 01:19 PM
-- Server version: 5.5.62-log
-- PHP Version: 7.4.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `departments_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `mechanical_engineering`
--

CREATE TABLE `mechanical_engineering` (
  `course_code` varchar(7) NOT NULL,
  `credit_unit` tinyint(4) NOT NULL,
  `level` enum('100','200','300','400','500') NOT NULL,
  `semester` enum('1st','2nd') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `mechanical_engineering`
--

INSERT INTO `mechanical_engineering` (`course_code`, `credit_unit`, `level`, `semester`) VALUES
('CHM 111', 3, '100', '1st'),
('CHM 112', 3, '100', '1st'),
('CHM 121', 3, '100', '2nd'),
('CHM 129', 1, '100', '2nd'),
('CVE 221', 2, '200', '2nd'),
('EEE 211', 2, '200', '1st'),
('EEE 221', 2, '200', '2nd'),
('EEE 222', 2, '200', '2nd'),
('EEE 315', 2, '300', '1st'),
('EEE 516', 2, '500', '1st'),
('EEE 525', 1, '500', '2nd'),
('GET 211', 3, '200', '1st'),
('GET 212', 2, '200', '1st'),
('GET 219', 2, '200', '1st'),
('GET 221', 3, '200', '2nd'),
('GET 223', 3, '200', '2nd'),
('GET 229', 2, '200', '2nd'),
('GET 299', 2, '200', '2nd'),
('GET 311', 3, '300', '1st'),
('GET 321', 3, '300', '2nd'),
('GET 322', 1, '300', '2nd'),
('GET 399', 3, '300', '2nd'),
('GET 411', 3, '400', '1st'),
('GET 429', 6, '400', '2nd'),
('GET 511', 2, '500', '1st'),
('GET 521', 2, '500', '2nd'),
('GSE 111', 2, '100', '1st'),
('GSE 112', 1, '100', '1st'),
('GSE 113', 2, '100', '1st'),
('GSE 121', 2, '100', '2nd'),
('GSE 122', 2, '100', '2nd'),
('GSE 123', 1, '100', '2nd'),
('GSE 124', 1, '100', '2nd'),
('GSE 311', 2, '300', '1st'),
('MEE 211', 2, '200', '1st'),
('MEE 212', 2, '200', '1st'),
('MEE 213', 2, '200', '1st'),
('MEE 214', 2, '200', '1st'),
('MEE 215', 2, '200', '1st'),
('MEE 216', 2, '200', '1st'),
('MEE 221', 2, '200', '2nd'),
('MEE 222', 2, '200', '2nd'),
('MEE 224', 2, '200', '2nd'),
('MEE 311', 1, '300', '1st'),
('MEE 312', 2, '300', '1st'),
('MEE 313', 2, '300', '1st'),
('MEE 314', 2, '300', '1st'),
('MEE 315', 2, '300', '1st'),
('MEE 316', 2, '300', '1st'),
('MEE 317', 1, '300', '1st'),
('MEE 319', 3, '300', '1st'),
('MEE 321', 2, '300', '2nd'),
('MEE 322', 2, '300', '2nd'),
('MEE 323', 2, '300', '2nd'),
('MEE 324', 2, '300', '2nd'),
('MEE 326', 2, '300', '2nd'),
('MEE 327', 2, '300', '2nd'),
('MEE 329', 3, '300', '2nd'),
('MEE 411', 3, '400', '1st'),
('MEE 414', 2, '400', '1st'),
('MEE 415', 2, '400', '1st'),
('MEE 416', 2, '400', '1st'),
('MEE 417', 3, '400', '1st'),
('MEE 418', 1, '400', '1st'),
('MEE 419', 3, '400', '1st'),
('MEE 511', 2, '500', '1st'),
('MEE 512', 2, '500', '1st'),
('MEE 513', 3, '500', '1st'),
('MEE 514', 2, '500', '1st'),
('MEE 515', 2, '500', '1st'),
('MEE 521', 2, '500', '2nd'),
('MEE 522', 2, '500', '2nd'),
('MEE 523', 2, '500', '2nd'),
('MEE 524', 3, '500', '2nd'),
('MEE 525', 3, '500', '2nd'),
('MEE 531', 3, '500', '1st'),
('MEE 535', 3, '500', '1st'),
('MEE 598', 6, '500', '2nd'),
('MTH 111', 3, '100', '1st'),
('MTH 112', 2, '100', '1st'),
('MTH 121', 3, '100', '2nd'),
('MTH 123', 3, '100', '2nd'),
('PEE 211', 1, '200', '1st'),
('PHY 111', 3, '100', '1st'),
('PHY 119', 1, '100', '1st'),
('PHY 121', 3, '100', '2nd'),
('PHY 122', 2, '100', '2nd'),
('PHY 129', 1, '100', '2nd');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `mechanical_engineering`
--
ALTER TABLE `mechanical_engineering`
  ADD PRIMARY KEY (`course_code`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

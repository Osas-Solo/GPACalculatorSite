-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 03, 2020 at 12:29 PM
-- Server version: 5.5.62-log
-- PHP Version: 7.4.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `departments_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `geology`
--

CREATE TABLE `geology` (
  `course_code` varchar(7) NOT NULL,
  `credit_unit` tinyint(4) NOT NULL,
  `level` enum('100','200','300','400') NOT NULL,
  `semester` enum('1st','2nd') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `geology`
--

INSERT INTO `geology` (`course_code`, `credit_unit`, `level`, `semester`) VALUES
('AGP 222', 2, '200', '2nd'),
('BIO 111', 3, '100', '1st'),
('BIO 121', 3, '100', '2nd'),
('BIO 129', 1, '100', '2nd'),
('CHM 112', 3, '100', '1st'),
('CHM 121', 3, '100', '2nd'),
('CHM 129', 1, '100', '2nd'),
('CHM 213', 2, '200', '1st'),
('CHM 221', 3, '200', '2nd'),
('CSC 111', 3, '100', '1st'),
('GLY 111', 3, '100', '1st'),
('GLY 121', 3, '100', '2nd'),
('GLY 211', 2, '200', '1st'),
('GLY 212', 3, '200', '1st'),
('GLY 213', 3, '200', '1st'),
('GLY 214', 2, '200', '1st'),
('GLY 215', 3, '200', '1st'),
('GLY 216', 3, '200', '1st'),
('GLY 221', 2, '200', '2nd'),
('GLY 222', 2, '200', '2nd'),
('GLY 223', 3, '200', '2nd'),
('GLY 224', 3, '200', '2nd'),
('GLY 311', 2, '300', '1st'),
('GLY 312', 3, '300', '1st'),
('GLY 313', 2, '300', '1st'),
('GLY 314', 2, '300', '1st'),
('GLY 315', 3, '300', '1st'),
('GLY 316', 2, '300', '1st'),
('GLY 317', 2, '300', '1st'),
('GLY 318', 2, '300', '1st'),
('GLY 320', 6, '300', '2nd'),
('GLY 321', 2, '300', '2nd'),
('GLY 322', 3, '300', '2nd'),
('GLY 323', 2, '300', '2nd'),
('GLY 324', 2, '300', '2nd'),
('GLY 325', 3, '300', '2nd'),
('GLY 326', 3, '300', '2nd'),
('GLY 411', 2, '400', '1st'),
('GLY 412', 3, '400', '1st'),
('GLY 413', 3, '400', '1st'),
('GLY 414', 2, '400', '1st'),
('GLY 415', 2, '400', '1st'),
('GLY 416', 2, '400', '1st'),
('GLY 417', 3, '400', '1st'),
('GLY 418', 2, '400', '1st'),
('GLY 419', 2, '400', '1st'),
('GLY 421', 3, '400', '2nd'),
('GLY 422', 2, '400', '2nd'),
('GLY 423', 2, '400', '2nd'),
('GLY 424', 2, '400', '2nd'),
('GLY 425', 2, '400', '2nd'),
('GLY 426', 2, '400', '2nd'),
('GLY 427', 3, '400', '2nd'),
('GLY 428', 2, '400', '2nd'),
('GLY 429', 6, '400', '2nd'),
('GSE 111', 2, '100', '1st'),
('GSE 112', 1, '100', '1st'),
('GSE 121', 2, '100', '2nd'),
('GSE 123', 1, '100', '2nd'),
('GSE 124', 1, '100', '2nd'),
('GSE 211', 3, '200', '1st'),
('GSE 221', 2, '200', '2nd'),
('GSE 311', 2, '300', '1st'),
('MTH 111', 3, '100', '1st'),
('MTH 121', 3, '100', '2nd'),
('MTH 122', 4, '100', '2nd'),
('PHY 111', 3, '100', '1st'),
('PHY 119', 1, '100', '1st'),
('PHY 121', 3, '100', '2nd'),
('PHY 129', 1, '100', '2nd');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `geology`
--
ALTER TABLE `geology`
  ADD PRIMARY KEY (`course_code`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

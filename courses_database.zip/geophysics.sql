-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 03, 2020 at 12:29 PM
-- Server version: 5.5.62-log
-- PHP Version: 7.4.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `departments_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `geophysics`
--

CREATE TABLE `geophysics` (
  `course_code` varchar(7) NOT NULL,
  `credit_unit` tinyint(4) NOT NULL,
  `level` enum('100','200','300','400') NOT NULL,
  `semester` enum('1st','2nd') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `geophysics`
--

INSERT INTO `geophysics` (`course_code`, `credit_unit`, `level`, `semester`) VALUES
('AGP 211', 2, '200', '1st'),
('AGP 221', 2, '200', '2nd'),
('AGP 222', 2, '200', '2nd'),
('AGP 311', 3, '300', '1st'),
('AGP 320', 6, '300', '2nd'),
('AGP 321', 3, '300', '2nd'),
('AGP 322', 3, '300', '2nd'),
('AGP 324', 2, '300', '2nd'),
('AGP 411', 3, '400', '1st'),
('AGP 412', 2, '400', '1st'),
('AGP 413', 3, '400', '1st'),
('AGP 414', 2, '400', '1st'),
('AGP 415', 3, '400', '1st'),
('AGP 416', 3, '400', '1st'),
('AGP 421', 2, '400', '2nd'),
('AGP 422', 2, '400', '2nd'),
('AGP 423', 2, '400', '2nd'),
('AGP 424', 2, '400', '2nd'),
('AGP 426', 6, '400', '2nd'),
('CHM 112', 3, '100', '1st'),
('CHM 121', 3, '100', '2nd'),
('CHM 129', 1, '100', '2nd'),
('CSC 111', 3, '100', '1st'),
('CSC 211', 3, '200', '1st'),
('CSC 221', 3, '200', '2nd'),
('GLY 111', 3, '100', '1st'),
('GLY 121', 3, '100', '2nd'),
('GLY 211', 2, '200', '1st'),
('GLY 214', 2, '200', '1st'),
('GLY 215', 3, '200', '1st'),
('GLY 221', 2, '200', '2nd'),
('GLY 222', 2, '200', '2nd'),
('GLY 223', 3, '200', '2nd'),
('GLY 311', 2, '300', '1st'),
('GLY 312', 2, '300', '1st'),
('GLY 314', 2, '300', '1st'),
('GLY 322', 3, '300', '2nd'),
('GLY 323', 2, '300', '2nd'),
('GLY 324', 2, '300', '2nd'),
('GLY 418', 2, '400', '1st'),
('GLY 423', 2, '400', '2nd'),
('GLY 427', 3, '400', '2nd'),
('GSE 111', 2, '100', '1st'),
('GSE 112', 1, '100', '1st'),
('GSE 121', 2, '100', '2nd'),
('GSE 123', 1, '100', '2nd'),
('GSE 124', 1, '100', '2nd'),
('GSE 211', 3, '200', '1st'),
('GSE 221', 2, '200', '2nd'),
('GSE 311', 2, '300', '1st'),
('MTH 111', 3, '100', '1st'),
('MTH 121', 3, '100', '2nd'),
('MTH 122', 4, '100', '2nd'),
('MTH 123', 3, '100', '2nd'),
('MTH 211', 3, '200', '1st'),
('MTH 221', 3, '200', '2nd'),
('MTH 312', 3, '300', '1st'),
('MTH 315', 3, '300', '1st'),
('MTH 416', 3, '400', '1st'),
('MTH 423', 3, '400', '2nd'),
('PHY 111', 3, '100', '1st'),
('PHY 119', 1, '100', '1st'),
('PHY 121', 3, '100', '2nd'),
('PHY 129', 1, '100', '2nd'),
('PHY 213', 3, '200', '1st'),
('PHY 221', 2, '200', '2nd'),
('PHY 312', 3, '300', '1st'),
('PHY 414', 2, '400', '1st');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `geophysics`
--
ALTER TABLE `geophysics`
  ADD PRIMARY KEY (`course_code`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 03, 2020 at 12:29 PM
-- Server version: 5.5.62-log
-- PHP Version: 7.4.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `departments_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `environmental_management_and_toxicology`
--

CREATE TABLE `environmental_management_and_toxicology` (
  `course_code` varchar(7) NOT NULL,
  `credit_unit` tinyint(4) NOT NULL,
  `level` enum('100','200','300','400','500') NOT NULL,
  `semester` enum('1st','2nd') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `environmental_management_and_toxicology`
--

INSERT INTO `environmental_management_and_toxicology` (`course_code`, `credit_unit`, `level`, `semester`) VALUES
('BIO 111', 3, '100', '1st'),
('BIO 119', 1, '100', '1st'),
('BIO 129', 1, '100', '2nd'),
('CHM 111', 3, '100', '1st'),
('CHM 112', 3, '100', '1st'),
('CHM 119', 1, '100', '1st'),
('CHM 121', 3, '100', '2nd'),
('CHM 129', 1, '100', '2nd'),
('CHM 212', 2, '200', '1st'),
('CHM 222', 2, '200', '2nd'),
('CSC 111', 2, '100', '1st'),
('CSC 211', 3, '200', '1st'),
('EMT 121', 3, '100', '2nd'),
('EMT 211', 2, '200', '1st'),
('EMT 212', 3, '200', '1st'),
('EMT 213', 2, '200', '1st'),
('EMT 214', 2, '200', '1st'),
('EMT 221', 3, '200', '2nd'),
('EMT 222', 3, '200', '2nd'),
('EMT 223', 3, '200', '2nd'),
('EMT 224', 2, '200', '2nd'),
('EMT 225', 3, '200', '2nd'),
('EMT 226', 3, '200', '2nd'),
('EMT 311', 2, '300', '1st'),
('EMT 312', 2, '300', '1st'),
('EMT 313', 3, '300', '1st'),
('EMT 314', 3, '300', '1st'),
('EMT 315', 3, '300', '1st'),
('EMT 316', 3, '300', '1st'),
('EMT 317', 2, '300', '1st'),
('EMT 318', 2, '300', '1st'),
('EMT 321', 2, '300', '2nd'),
('EMT 322', 3, '300', '2nd'),
('EMT 323', 2, '300', '2nd'),
('EMT 324', 3, '300', '2nd'),
('EMT 325', 2, '300', '2nd'),
('EMT 326', 3, '300', '2nd'),
('EMT 327', 3, '300', '2nd'),
('EMT 328', 3, '300', '2nd'),
('EMT 411', 2, '400', '1st'),
('EMT 412', 2, '400', '1st'),
('EMT 413', 2, '400', '1st'),
('EMT 414', 2, '400', '1st'),
('EMT 415', 2, '400', '1st'),
('EMT 416', 2, '400', '1st'),
('EMT 417', 3, '400', '1st'),
('EMT 418', 3, '400', '1st'),
('EMT 419', 3, '400', '1st'),
('EMT 429', 6, '400', '2nd'),
('EMT 511', 2, '500', '1st'),
('EMT 512', 2, '500', '1st'),
('EMT 513', 3, '500', '1st'),
('EMT 514', 2, '500', '1st'),
('EMT 515', 3, '500', '1st'),
('EMT 516', 3, '500', '1st'),
('EMT 517', 3, '500', '1st'),
('EMT 518', 2, '500', '1st'),
('EMT 521', 2, '500', '2nd'),
('EMT 522', 3, '500', '2nd'),
('EMT 523', 3, '500', '2nd'),
('EMT 524', 3, '500', '2nd'),
('EMT 525', 3, '500', '2nd'),
('EMT 526', 2, '500', '2nd'),
('EMT 529', 6, '500', '2nd'),
('GSE 111', 2, '100', '1st'),
('GSE 112', 1, '100', '1st'),
('GSE 121', 2, '100', '2nd'),
('GSE 123', 1, '100', '2nd'),
('GSE 124', 1, '100', '2nd'),
('GSE 211', 3, '200', '1st'),
('GSE 221', 2, '200', '2nd'),
('GSE 311', 2, '300', '1st'),
('MTH 111', 3, '100', '1st'),
('MTH 121', 3, '100', '2nd'),
('PHY 111', 3, '100', '1st'),
('PHY 119', 1, '100', '1st'),
('PHY 121', 3, '100', '2nd'),
('PHY 129', 1, '100', '2nd');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `environmental_management_and_toxicology`
--
ALTER TABLE `environmental_management_and_toxicology`
  ADD PRIMARY KEY (`course_code`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

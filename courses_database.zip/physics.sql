-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 03, 2020 at 12:30 PM
-- Server version: 5.5.62-log
-- PHP Version: 7.4.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `departments_database`
--

-- --------------------------------------------------------

--
-- Table structure for table `physics`
--

CREATE TABLE `physics` (
  `course_code` varchar(7) NOT NULL,
  `credit_unit` tinyint(4) NOT NULL,
  `level` enum('100','200','300','400') NOT NULL,
  `semester` enum('1st','2nd') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `physics`
--

INSERT INTO `physics` (`course_code`, `credit_unit`, `level`, `semester`) VALUES
('BIO 111', 3, '100', '1st'),
('BIO 119', 1, '100', '1st'),
('CHM 111', 3, '100', '1st'),
('CHM 119', 1, '100', '1st'),
('CHM 121', 3, '100', '2nd'),
('CHM 129', 1, '100', '2nd'),
('CSC 111', 3, '100', '1st'),
('CSC 211', 3, '200', '1st'),
('CSC 221', 3, '200', '2nd'),
('GSE 111', 2, '100', '1st'),
('GSE 112', 1, '100', '1st'),
('GSE 121', 2, '100', '2nd'),
('GSE 123', 1, '100', '2nd'),
('GSE 124', 1, '100', '2nd'),
('GSE 211', 2, '200', '1st'),
('GSE 221', 2, '200', '2nd'),
('MTH 111', 3, '100', '1st'),
('MTH 121', 3, '100', '2nd'),
('MTH 123', 3, '100', '2nd'),
('MTH 211', 3, '200', '1st'),
('MTH 221', 3, '200', '2nd'),
('MTH 223', 3, '200', '2nd'),
('PHY 111', 3, '100', '1st'),
('PHY 119', 1, '100', '1st'),
('PHY 121', 3, '100', '2nd'),
('PHY 122', 2, '100', '2nd'),
('PHY 123', 2, '100', '2nd'),
('PHY 129', 1, '100', '2nd'),
('PHY 211', 3, '200', '1st'),
('PHY 212', 2, '200', '1st'),
('PHY 213', 3, '200', '1st'),
('PHY 219', 1, '200', '1st'),
('PHY 221', 2, '200', '2nd'),
('PHY 222', 3, '200', '2nd'),
('PHY 223', 3, '200', '2nd'),
('PHY 229', 1, '200', '2nd'),
('PHY 300', 2, '300', '1st'),
('PHY 311', 3, '300', '1st'),
('PHY 312', 3, '300', '1st'),
('PHY 313', 3, '300', '1st'),
('PHY 314', 3, '300', '1st'),
('PHY 315', 2, '300', '1st'),
('PHY 316', 2, '300', '1st'),
('PHY 320', 6, '300', '2nd'),
('PHY 411', 3, '400', '1st'),
('PHY 412', 3, '400', '1st'),
('PHY 413', 3, '400', '1st'),
('PHY 414', 3, '400', '1st'),
('PHY 415', 3, '400', '1st'),
('PHY 416', 2, '400', '1st'),
('PHY 417', 3, '400', '1st'),
('PHY 418', 2, '400', '1st'),
('PHY 420', 6, '400', '2nd'),
('PHY 421', 3, '400', '2nd'),
('PHY 422', 3, '400', '2nd'),
('PHY 423', 3, '400', '2nd'),
('PHY 424', 3, '400', '2nd'),
('PHY 425', 2, '400', '2nd'),
('PHY 426', 2, '400', '2nd'),
('PHY 427', 2, '400', '2nd'),
('PHY 431', 2, '400', '2nd'),
('PHY 432', 2, '400', '2nd');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `physics`
--
ALTER TABLE `physics`
  ADD PRIMARY KEY (`course_code`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
